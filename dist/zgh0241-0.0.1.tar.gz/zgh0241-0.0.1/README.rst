# zgh0241
zgh_autotest
基于Python+Selenium的UI自动化测试框架
用例管理：EXECL