from setuptools import setup, find_packages

setup(
    name = "zgh0241",
    version = "0.0.1",
    description=('基于Python+Selenium的UI自动化测试框架'),
    author='zgh',
    author_email='18857757067@163.com',
    license='BSD License',
    packages=find_packages(),
    platforms=["all"],
    url='https://github.com/zgh0241/zgh0241',
    install_requires=[]
)
